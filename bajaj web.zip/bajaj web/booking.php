<?php 
$name = $_POST['name'];
$email = $_POST['email'];
$service = $_POST['service'];
$servicedate = $_POST['servicedate'];
$specialrequest = $_POST['specialrequest']; 

// Establish connection to MySQL database
$conn = new mysqli('localhost', 'root', '', 'booking');

// Check connection
if($conn->connect_error) {
    die('Connection Failed: ' . $conn->connect_error);
} else {
    // Prepare SQL statement to insert data
    $stmt = $conn->prepare("INSERT INTO booking (name, email, service, servicedate, specialrequest) VALUES (?, ?, ?, ?, ?)");
    
    // Bind parameters to the prepared statement
    $stmt->bind_param("sssis", $name, $email, $service, $servicedate, $specialrequest);
    
    // Execute the prepared statement
    if ($stmt->execute()) {
        echo "Booking Successfully...";
    } else {
        echo "Error: " . $conn->error; // Print any errors if insertion fails
    }
    
    // Close the prepared statement
    $stmt->close();
    
    // Close the database connection
    $conn->close();
}
?>
